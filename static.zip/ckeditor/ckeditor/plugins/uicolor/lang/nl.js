﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uicolor","nl",{title:"UI Kleurenkiezer",preview:"Live voorbeeld",config:"Plak deze tekst in jouw config.js bestand",predefined:"Voorgedefinieerde kleurensets"});