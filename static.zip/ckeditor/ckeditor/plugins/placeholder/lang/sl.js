﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("placeholder","sl",{title:"Lastnosti Ograde",toolbar:"Ustvari Ogrado",name:"Placeholder Ime",invalidName:"Placeholder ne more biti prazen in ne sme vsebovati katerega od naslednjih znakov: [, ], <, >",pathName:"placeholder"});